import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:sqlserver://localhost\\sqlexpress\\:1434;databaseName=Hotel";
    private static final String USER = "hoteladmin";
    private static final String PASSWORD = "hoteladmin";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
