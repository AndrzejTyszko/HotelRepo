use Hotel
go
CREATE TABLE Rooms (
    RoomID INT PRIMARY KEY IDENTITY,
    RoomNumber INT NOT NULL,
    RoomType NVARCHAR(50) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Reservations (
    ReservationID INT PRIMARY KEY IDENTITY,
    RoomID INT FOREIGN KEY REFERENCES Rooms(RoomID),
    GuestName NVARCHAR(100) NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL
);
go

CREATE PROCEDURE CreateReservation
    @RoomID INT,
    @GuestName NVARCHAR(100),
    @CheckInDate DATE,
    @CheckOutDate DATE
AS
BEGIN
    INSERT INTO Reservations (RoomID, GuestName, CheckInDate, CheckOutDate)
    VALUES (@RoomID, @GuestName, @CheckInDate, @CheckOutDate);
END;
go

CREATE PROCEDURE GetReservations
AS
BEGIN
    SELECT r.RoomNumber, r.RoomType, res.GuestName, res.CheckInDate, res.CheckOutDate
    FROM Reservations res
    JOIN Rooms r ON res.RoomID = r.RoomID;
END;


	insert into Rooms values(1,'A',111)

	GO
	CREATE PROCEDURE CreateRoom
    @RoomNumber INT,
    @RoomType NVARCHAR(50),
    @Price DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO Rooms (RoomNumber, RoomType, Price)
    VALUES (@RoomNumber, @RoomType, @Price);
END;
go
CREATE PROCEDURE CheckRoomExists
    @RoomNumber INT,
    @RoomExists BIT OUTPUT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Rooms WHERE RoomNumber = @RoomNumber)
    BEGIN
        SET @RoomExists = 1;
    END
    ELSE
    BEGIN
        SET @RoomExists = 0;
    END
END;
GO

CREATE PROCEDURE CheckRoomAvailability
    @RoomID INT,
    @CheckInDate DATE,
    @CheckOutDate DATE,
    @IsAvailable BIT OUTPUT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Reservations WHERE RoomID = @RoomID AND ((CheckInDate <= @CheckOutDate AND CheckInDate >= @CheckInDate) OR (CheckOutDate <= @CheckOutDate AND CheckOutDate >= @CheckInDate)))
    BEGIN
        SET @IsAvailable = 0;
    END
    ELSE
    BEGIN
        SET @IsAvailable = 1;
    END
END;
go
CREATE PROCEDURE GetRoomNumbers
AS
BEGIN
    SELECT RoomNumber FROM Rooms;
END;
go
CREATE PROCEDURE GetRooms
AS
BEGIN
    SELECT RoomNumber, RoomType, Price
    FROM Rooms
END

GO

CREATE PROCEDURE GetReservations2
AS
BEGIN
    SELECT RoomNumber, RoomType, GuestName, CheckInDate, CheckOutDate, Price
    FROM Reservations
    JOIN Rooms ON Reservations.RoomID = Rooms.RoomID
END
go

CREATE PROCEDURE DeleteReservation
    @RoomNumber INT,
    @CheckInDate DATE,
    @CheckOutDate DATE
AS
BEGIN
    DELETE FROM Reservations
    WHERE RoomID = (SELECT RoomID FROM Rooms WHERE RoomNumber = @RoomNumber)
    AND CheckInDate = @CheckInDate
    AND CheckOutDate = @CheckOutDate;
END;
GO

USE Hotel
GO

CREATE PROCEDURE DeleteRoom
    @RoomNumber INT
AS
BEGIN
    DELETE FROM Rooms
    WHERE RoomNumber = @RoomNumber;
END;
GO

use master
go
create login hoteladmin with password ='hoteladmin'
go
use Hotel;
go
create user hoteladmin for login hoteladmin;
go
grant all on database Hotel to user hoteladmin

go

EXEC sp_addrolemember @rolename = 'db_owner', @membername = 'hoteladmin';
GO
USE [Hotel];
GO

-- Uprawnienia do tworzenia obiektów
GRANT CREATE TABLE TO hoteladmin;
GRANT CREATE VIEW TO hoteladmin;
GRANT CREATE PROCEDURE TO hoteladmin;
GRANT CREATE FUNCTION TO hoteladmin;

-- Uprawnienia do modyfikowania danych
GRANT SELECT ON SCHEMA :: dbo TO hoteladmin;
GRANT INSERT ON SCHEMA :: dbo TO hoteladmin;
GRANT UPDATE ON SCHEMA :: dbo TO hoteladmin;
GRANT DELETE ON SCHEMA :: dbo TO hoteladmin;