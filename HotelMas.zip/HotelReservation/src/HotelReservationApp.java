import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class HotelReservationApp extends JFrame {
    private JPanel mainPanel;
    private JTabbedPane tabbedPane;
    private JPanel reservationPanel;
    private JPanel viewReservationsPanel;
    private JPanel createRoomPanel;
    private JPanel loginPanel;
    private JTextField guestNameField;
    private JComboBox<String> roomNumberField;
    private JTextField checkInDateField;
    private JTextField checkOutDateField;
    private JTextArea reservationsArea;
    private JTable reservationsTable;
    private DefaultTableModel tableModel;
    private JButton reserveButton;
    private JButton loadReservationsButton;
    private JTextField roomNumberCreateField;
    private JTextField roomTypeCreateField;
    private JTextField roomPriceCreateField;
    private JButton createRoomButton;
    private JButton deleteRoomButton;
    private JTable roomsTable;
    private DefaultTableModel roomsTableModel;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    
    private JLabel totalRoomsReservedLabel;
    private JLabel totalPriceLabel;

    public HotelReservationApp() {
        setTitle("Hotel Reservation System");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainPanel = new JPanel(new CardLayout());
        tabbedPane = new JTabbedPane();

        // Dodanie obrazu
        loginPanel = new JPanel(new BorderLayout());

       
JLabel backgroundLabel = new JLabel(new ImageIcon(getClass().getResource("/rescures/hotelbackground.jpg")));
        backgroundLabel.setLayout(new BorderLayout());
        

        // nazwa apki
        JLabel appNameLabel = new JLabel("Hotel Reservation", JLabel.CENTER);
        appNameLabel.setFont(new Font("Serif", Font.BOLD, 32));
        appNameLabel.setForeground(Color.WHITE);

      
        JPanel loginFormPanel = new JPanel(new GridBagLayout());
        loginFormPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.WHITE);
        loginFormPanel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        usernameField = new JTextField(15);
        loginFormPanel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        loginFormPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        loginFormPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        loginButton = new JButton("Login");
        loginButton.addActionListener(new LoginButtonListener());
        loginFormPanel.add(loginButton, gbc);

        backgroundLabel.add(appNameLabel, BorderLayout.NORTH);
        backgroundLabel.add(loginFormPanel, BorderLayout.CENTER);

        loginPanel.add(backgroundLabel, BorderLayout.CENTER);

        mainPanel.add(loginPanel, "Login");

        // Rezerwacja
        reservationPanel = new JPanel(new GridLayout(5, 2));
        reservationPanel.add(new JLabel("Guest Name:"));
        guestNameField = new JTextField();
        reservationPanel.add(guestNameField);

        reservationPanel.add(new JLabel("Room Number:"));
        roomNumberField = new JComboBox<>();
        reservationPanel.add(roomNumberField);

        reservationPanel.add(new JLabel("Check-In Date (YYYY-MM-DD):"));
        checkInDateField = new JTextField();
        reservationPanel.add(checkInDateField);

        reservationPanel.add(new JLabel("Check-Out Date (YYYY-MM-DD):"));
        checkOutDateField = new JTextField();
        reservationPanel.add(checkOutDateField);

        reserveButton = new JButton("Reserve");
        reservationPanel.add(reserveButton);
        reserveButton.addActionListener(new ReserveButtonListener());

        tabbedPane.add("Create Reservation", reservationPanel);

        // Panel wyświetlania rezerwacji
        viewReservationsPanel = new JPanel(new BorderLayout());
        tableModel = new DefaultTableModel(new String[]{"Room Number", "Room Type", "Guest Name", "Check-In Date", "Check-Out Date"}, 0);
        reservationsTable = new JTable(tableModel);
        viewReservationsPanel.add(new JScrollPane(reservationsTable), BorderLayout.CENTER);
        loadReservationsButton = new JButton("Load Reservations");
        viewReservationsPanel.add(loadReservationsButton, BorderLayout.NORTH);
        loadReservationsButton.addActionListener(new LoadReservationsButtonListener());

        // Context menu usuwanie
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem deleteMenuItem = new JMenuItem("Delete Reservation");
        popupMenu.add(deleteMenuItem);
        deleteMenuItem.addActionListener(new DeleteReservationListener());
        reservationsTable.setComponentPopupMenu(popupMenu);
        reservationsTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    showPopup(e);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    showPopup(e);
                }
            }

            private void showPopup(MouseEvent e) {
                int row = reservationsTable.rowAtPoint(e.getPoint());
                reservationsTable.setRowSelectionInterval(row, row);
                popupMenu.show(e.getComponent(), e.getX(), e.getY());
            }
        });

        // suma rezerwacji
        JPanel summaryPanel = new JPanel(new GridLayout(1, 2));
        totalRoomsReservedLabel = new JLabel("Total Rooms Reserved: 0");
        totalPriceLabel = new JLabel("Total Price: $0.00");
        summaryPanel.add(totalRoomsReservedLabel);
        summaryPanel.add(totalPriceLabel);
        viewReservationsPanel.add(summaryPanel, BorderLayout.SOUTH);

        tabbedPane.add("View Reservations", viewReservationsPanel);

        // Pokoje
        createRoomPanel = new JPanel(new BorderLayout());
        JPanel roomFormPanel = new JPanel(new GridLayout(5, 2));
        roomFormPanel.add(new JLabel("Room Number:"));
        roomNumberCreateField = new JTextField();
        roomFormPanel.add(roomNumberCreateField);

        roomFormPanel.add(new JLabel("Room Type:"));
        roomTypeCreateField = new JTextField();
        roomFormPanel.add(roomTypeCreateField);

        roomFormPanel.add(new JLabel("Room Price:"));
        roomPriceCreateField = new JTextField();
        roomFormPanel.add(roomPriceCreateField);

        createRoomButton = new JButton("Create Room");
        roomFormPanel.add(createRoomButton);
        createRoomButton.addActionListener(new CreateRoomButtonListener());

        deleteRoomButton = new JButton("Delete Room");
        roomFormPanel.add(deleteRoomButton);
        deleteRoomButton.addActionListener(new DeleteRoomButtonListener());

        createRoomPanel.add(roomFormPanel, BorderLayout.NORTH);

        roomsTableModel = new DefaultTableModel(new String[]{"Room Number", "Room Type", "Room Price"}, 0);
        roomsTable = new JTable(roomsTableModel);
        createRoomPanel.add(new JScrollPane(roomsTable), BorderLayout.CENTER);

        tabbedPane.add("Create Room", createRoomPanel);

      
        tabbedPane.addChangeListener(new TabChangeListener());

        mainPanel.add(tabbedPane, "Main");
        add(mainPanel);
    }

    private class LoginButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            if ("admin".equals(username) && "admin".equals(password)) {
                CardLayout cl = (CardLayout) (mainPanel.getLayout());
                cl.show(mainPanel, "Main");
                loadRoomNumbers();
            } else {
                JOptionPane.showMessageDialog(HotelReservationApp.this, "Invalid login credentials!");
            }
        }
    }

    private void loadRoomNumbers() {
        roomNumberField.removeAllItems();
        try (Connection conn = DatabaseConnection.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call GetRoomNumbers}");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                roomNumberField.addItem(String.valueOf(rs.getInt("RoomNumber")));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(HotelReservationApp.this, "Error loading room numbers!");
        }
    }

    private void loadRooms() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call GetRooms}");
            ResultSet rs = stmt.executeQuery();

            roomsTableModel.setRowCount(0); // Clear existing rows
            while (rs.next()) {
                String roomNumber = rs.getString("RoomNumber");
                String roomType = rs.getString("RoomType");
                double Price = rs.getDouble("Price");

                roomsTableModel.addRow(new Object[]{roomNumber, roomType, Price});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(HotelReservationApp.this, "Error loading rooms!");
        }
    }

    private void loadReservations() {
        int totalRoomsReserved = 0;
        double totalPrice = 0.0;

        try (Connection conn = DatabaseConnection.getConnection()) {
            CallableStatement stmt = conn.prepareCall("{call GetReservations2}");
            ResultSet rs = stmt.executeQuery();

            tableModel.setRowCount(0); // Clear existing rows
            while (rs.next()) {
                String roomNumber = rs.getString("RoomNumber");
                String roomType = rs.getString("RoomType");
                String guestName = rs.getString("GuestName");
                String checkInDate = rs.getString("CheckInDate");
                String checkOutDate = rs.getString("CheckOutDate");
                double Price = rs.getDouble("Price");

                tableModel.addRow(new Object[]{roomNumber, roomType, guestName, checkInDate, checkOutDate});
                totalRoomsReserved++;
                totalPrice += Price;
            }

            // Update summary labels
            totalRoomsReservedLabel.setText("Total Rooms Reserved: " + totalRoomsReserved);
            totalPriceLabel.setText(String.format("Total Price: $%.2f", totalPrice));
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(HotelReservationApp.this, "Error loading reservations!");
        }
    }

    private class TabChangeListener implements ChangeListener {
        @Override
        public void stateChanged(ChangeEvent e) {
            if (tabbedPane.getSelectedIndex() == 0) { // Reservation tab
                loadRoomNumbers();
            } else if (tabbedPane.getSelectedIndex() == 1) { // View Reservations tab
                loadReservations();
            } else if (tabbedPane.getSelectedIndex() == 2) { // Create Room tab
                loadRooms();
            }
        }
    }

    private class ReserveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String guestName = guestNameField.getText();
            int roomNumber = Integer.parseInt((String) roomNumberField.getSelectedItem());
            String checkInDate = checkInDateField.getText();
            String checkOutDate = checkOutDateField.getText();

            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            try {
                LocalDate checkIn = LocalDate.parse(checkInDate, formatter);
                LocalDate checkOut = LocalDate.parse(checkOutDate, formatter);
                if (checkIn.isBefore(today) || checkOut.isBefore(today)) {
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Check-in and check-out dates must be today or in the future!");
                    return;
                }
                if (checkOut.isBefore(checkIn) || checkOut.isEqual(checkIn)) {
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Check-out date must be after check-in date!");
                    return;
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(HotelReservationApp.this, "Invalid date format! Use YYYY-MM-DD.");
                return;
            }

            try (Connection conn = DatabaseConnection.getConnection()) {
                String getRoomIDQuery = "SELECT RoomID FROM Rooms WHERE RoomNumber = ?";
                PreparedStatement getRoomIDStmt = conn.prepareStatement(getRoomIDQuery);
                getRoomIDStmt.setInt(1, roomNumber);
                ResultSet rs = getRoomIDStmt.executeQuery();
                if (rs.next()) {
                    int roomID = rs.getInt("RoomID");

                    CallableStatement checkAvailabilityStmt = conn.prepareCall("{call CheckRoomAvailability(?, ?, ?, ?)}");
                    checkAvailabilityStmt.setInt(1, roomID);
                    checkAvailabilityStmt.setString(2, checkInDate);
                    checkAvailabilityStmt.setString(3, checkOutDate);
                    checkAvailabilityStmt.registerOutParameter(4, Types.BIT);
                    checkAvailabilityStmt.execute();
                    boolean isAvailable = checkAvailabilityStmt.getBoolean(4);

                    if (!isAvailable) {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Room is not available for the selected dates!");
                        return;
                    }

                    CallableStatement stmt = conn.prepareCall("{call CreateReservation(?, ?, ?, ?)}");
                    stmt.setInt(1, roomID);
                    stmt.setString(2, guestName);
                    stmt.setString(3, checkInDate);
                    stmt.setString(4, checkOutDate);
                    stmt.execute();

                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Reservation created successfully!");
                } else {
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Room not found!");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(HotelReservationApp.this, "Error creating reservation!");
            }
        }
    }

    private class LoadReservationsButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            loadReservations();
        }
    }

    private class CreateRoomButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int roomNumber = Integer.parseInt(roomNumberCreateField.getText());
            String roomType = roomTypeCreateField.getText();
            double Price = Double.parseDouble(roomPriceCreateField.getText());

            try (Connection conn = DatabaseConnection.getConnection()) {
                CallableStatement checkRoomExistsStmt = conn.prepareCall("{call CheckRoomExists(?, ?)}");
                checkRoomExistsStmt.setInt(1, roomNumber);
                checkRoomExistsStmt.registerOutParameter(2, Types.BIT);
                checkRoomExistsStmt.execute();
                boolean roomExists = checkRoomExistsStmt.getBoolean(2);

                if (roomExists) {
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Room number already exists!");
                    return;
                }

                CallableStatement stmt = conn.prepareCall("{call CreateRoom(?, ?, ?)}");
                stmt.setInt(1, roomNumber);
                stmt.setString(2, roomType);
                stmt.setDouble(3, Price);
                stmt.execute();

                JOptionPane.showMessageDialog(HotelReservationApp.this, "Room created successfully!");
                loadRooms(); // Refresh room list after creating a new room
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(HotelReservationApp.this, "Error creating room!");
            }
        }
    }

    private class DeleteRoomButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = roomsTable.getSelectedRow();
            if (selectedRow != -1) {
                String roomNumber = roomsTableModel.getValueAt(selectedRow, 0).toString();

                try (Connection conn = DatabaseConnection.getConnection()) {
                    // Sprawdź, czy pokój jest zarezerwowany
                    String checkRoomReservedQuery =
                        "SELECT COUNT(*) FROM Reservations r JOIN Rooms rm ON r.RoomID = rm.RoomID WHERE rm.RoomNumber = ?";
                    PreparedStatement checkRoomReservedStmt = conn.prepareStatement(checkRoomReservedQuery);
                    checkRoomReservedStmt.setInt(1, Integer.parseInt(roomNumber));
                    ResultSet rs = checkRoomReservedStmt.executeQuery();
                    rs.next();
                    int reservationCount = rs.getInt(1);

                    if (reservationCount > 0) {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Room is reserved and cannot be deleted!");
                        return;
                    }

                    // Usuń pokój, jeśli nie jest zarezerwowany
                    CallableStatement stmt = conn.prepareCall("{call DeleteRoom(?)}");
                    stmt.setInt(1, Integer.parseInt(roomNumber));
                    int affectedRows = stmt.executeUpdate();

                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Room deleted successfully!");
                        loadRooms();
                    } else {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Failed to delete room!");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Error deleting room!");
                }
            }
        }
    }

    private class DeleteReservationListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = reservationsTable.getSelectedRow();
            if (selectedRow != -1) {
                String roomNumber = tableModel.getValueAt(selectedRow, 0).toString();
                String checkInDate = tableModel.getValueAt(selectedRow, 3).toString();
                String checkOutDate = tableModel.getValueAt(selectedRow, 4).toString();

                try (Connection conn = DatabaseConnection.getConnection()) {
                    CallableStatement stmt = conn.prepareCall("{call DeleteReservation(?, ?, ?)}");
                    stmt.setInt(1, Integer.parseInt(roomNumber));
                    stmt.setString(2, checkInDate);
                    stmt.setString(3, checkOutDate);
                    int affectedRows = stmt.executeUpdate();

                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Reservation deleted successfully!");
                        loadReservations();
                    } else {
                        JOptionPane.showMessageDialog(HotelReservationApp.this, "Failed to delete reservation!");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(HotelReservationApp.this, "Error deleting reservation!");
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HotelReservationApp app = new HotelReservationApp();
            app.setVisible(true);
        });
    }
}